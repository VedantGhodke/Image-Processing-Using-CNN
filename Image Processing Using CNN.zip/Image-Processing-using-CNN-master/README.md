# Image-Processing-using-CNN
Image processing using convolutional neural network

The aim of this project is to use Deep Learning as a tool to correctly classify images of cats and dogs,using Dogs vs. Cats Redux: Kernels Edition dataset.

Training Dataset was created using 8000 imgaes of dogs & cats.
Test Data consist of 2000 images of dogs & cats.
